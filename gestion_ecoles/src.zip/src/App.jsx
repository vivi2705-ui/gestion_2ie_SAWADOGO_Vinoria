// src/App.jsx
import { BrowserRouter, Routes, Route, Navigate,Outlet } from 'react-router-dom';
import { AuthProvider }  from './context/AuthContext';
import ProtectedRoute    from './components/ProtectedRoute';
import LoginPage         from './pages/LoginPage';
import Dashboard         from './pages/Dashboard';
import Sidebar from './components/Sidebar';

function SidebarLayout() {
  return (
    <Sidebar>
      <Outlet /> 
    </Sidebar>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
       
        <Routes>
          {/* Route publique */}
          <Route path="/login" element={<LoginPage />} />


          {/* Routes protégées */}
          
          <Route element={<ProtectedRoute />}>
            
            <Route element={<Sidebar />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/dashboard" element={<Dashboard />} />
          </Route>
  

        
          </Route>

          {/* Redirection par défaut */}
          <Route path="*" element={<Navigate to="/login" replace />} />

        </Routes>
     
      </AuthProvider>
    </BrowserRouter>
  );
}
