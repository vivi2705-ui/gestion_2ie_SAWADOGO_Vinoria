import { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';

const Sidebar = ({ children }) => {
  const [open, setOpen] = useState(true);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [openSections, setOpenSections] = useState({ ressources: true, etudiants: true });

  // Detect screen size
  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (!mobile) setOpen(true);  // always open on desktop
      else setOpen(false);          // closed by default on mobile
    };
    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const toggleSection = (key) => {
    setOpenSections(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const RESSOURCES = [
    { path: '/ecoles',      label: 'Ecoles' },
    { path: '/filieres',    label: 'Filières' },
    { path: '/cycles',      label: 'Cycles' },
    { path: '/specialites', label: 'Spécialités' },
    { path: '/civilites',   label: 'Civilités' },
    { path: '/pays',        label: 'Pays' },
    { path: '/decisions',   label: 'Décisions' },
    { path: '/annees',      label: 'Années académiques' },
    { path: '/parcours',    label: 'Parcours' },
  ];

  const ETUDIANTS = [
    { path: '/ajouter',       label: "Ajouter étudiant" },
    { path: '/resultats',     label: "Résultats fin d'année" },
    { path: '/trombinoscope', label: 'Trombinoscope' },
    { path: '/liste',         label: 'Liste des étudiants' },
    { path: '/certificats',   label: "Certificats d'inscription" },
    { path: '/inscriptions',  label: 'Gestion inscriptions' },
    { path: '/nouvel',        label: 'Nouvel étudiant' },
  ];

  const subItemStyle = (isActive) => ({
    display: 'block',
    padding: '7px 16px 7px 32px',
    fontSize: '13px',
    color: isActive ? '#1e293b' : '#64748b',
    fontWeight: isActive ? '500' : '400',
    borderLeft: isActive ? '2px solid #3b82f6' : '2px solid transparent',
    textDecoration: 'none',
    transition: 'all 0.15s',
  });

  const sectionBtnStyle = {
    width: '100%',
    background: 'none',
    border: 'none',
    padding: '10px 16px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '500',
    color: '#1e293b',
    whiteSpace: 'nowrap',
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh', position: 'relative' }}>

      {/* Mobile overlay */}
      {isMobile && open && (
        <div
          onClick={() => setOpen(false)}
          style={{
            position: 'fixed', inset: 0,
            background: 'rgba(0,0,0,0.4)',
            zIndex: 40,
          }}
        />
      )}

      {/* Sidebar */}
      <div style={{
        position: isMobile ? 'fixed' : 'relative',
        top: 0, left: 0,
        height: '100%',
        width: '260px',
        minWidth: '260px',
        backgroundColor: '#f8fafc',
        borderRight: '1px solid #e2e8f0',
        display: 'flex',
        flexDirection: 'column',
        zIndex: 50,
        transform: isMobile
          ? (open ? 'translateX(0)' : 'translateX(-100%)')
          : (open ? 'translateX(0)' : 'translateX(-100%)'),
        transition: 'transform 0.25s ease',
        // Desktop collapse via width instead
        ...((!isMobile && !open) && { width: 0, minWidth: 0, overflow: 'hidden', transform: 'none' }),
        ...((!isMobile && open) && { transform: 'none' }),
      }}>
        <div style={{ padding: '16px', borderBottom: '1px solid #e2e8f0', fontSize: '11px', fontWeight: '600', color: '#94a3b8', letterSpacing: '0.08em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>
          2iE — Navigation
        </div>

        <nav style={{ flex: 1, overflowY: 'auto' }}>
          <button style={sectionBtnStyle} onClick={() => toggleSection('ressources')}>
            Ressources <span>{openSections.ressources ? '▾' : '▸'}</span>
          </button>
          {openSections.ressources && RESSOURCES.map(l => (
            <NavLink key={l.path} to={l.path} onClick={() => isMobile && setOpen(false)} style={({ isActive }) => subItemStyle(isActive)}>
              {l.label}
            </NavLink>
          ))}

          <button style={sectionBtnStyle} onClick={() => toggleSection('etudiants')}>
            Gestion des étudiants <span>{openSections.etudiants ? '▾' : '▸'}</span>
          </button>
          {openSections.etudiants && ETUDIANTS.map(l => (
            <NavLink key={l.path} to={l.path} onClick={() => isMobile && setOpen(false)} style={({ isActive }) => subItemStyle(isActive)}>
              {l.label}
            </NavLink>
          ))}
        </nav>
      </div>

      {/* Main content */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <div style={{ height: '52px', borderBottom: '1px solid #e2e8f0', display: 'flex', alignItems: 'center', padding: '0 16px', gap: '12px', flexShrink: 0 }}>
          <button
            onClick={() => setOpen(o => !o)}
            style={{ background: 'none', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '6px 10px', cursor: 'pointer', fontSize: '16px', flexShrink: 0 }}
          >
            ☰
          </button>
          <span style={{ fontWeight: '500', fontSize: '14px' }}>Menu</span>
        </div>
        <div style={{ flex: 1, padding: '24px', overflowY: 'auto' }}>
          {children}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;

// import { NavLink } from 'react-router-dom';

// const Sidebar = ({ children }) => {
//   const [open, setOpen] = useState(true);
//   const [openSections, setOpenSections] = useState({ ressources: true, etudiants: true });

//   const toggleSection = (key) => {
//     setOpenSections(prev => ({ ...prev, [key]: !prev[key] }));
//   };

//   const RESSOURCES = [
//     { path: '/ecoles', label: 'Ecoles' },
//     { path: '/filieres', label: 'Filières' },
//     { path: '/cycles', label: 'Cycles' },
//     { path: '/specialites', label: 'Spécialités' },
//     { path: '/civilites', label: 'Civilités' },
//     { path: '/pays', label: 'Pays' },
//     { path: '/decisions', label: 'Décisions' },
//     { path: '/annees', label: 'Années académiques' },
//     { path: '/parcours', label: 'Parcours' },
//   ];

//   const ETUDIANTS = [
//     { path: '/ajouter', label: 'Ajouter étudiant' },
//     { path: '/resultats', label: 'Résultats fin d\'année' },
//     { path: '/trombinoscope', label: 'Trombinoscope' },
//     { path: '/liste', label: 'Liste des étudiants' },
//     { path: '/certificats', label: 'Certificats d\'inscription' },
//     { path: '/inscriptions', label: 'Gestion inscriptions' },
//     { path: '/nouvel', label: 'Nouvel étudiant' },
//   ];

//   const subItemStyle = (isActive) => ({
//     display: 'block',
//     padding: '7px 16px 7px 32px',
//     fontSize: '13px',
//     color: isActive ? '#1e293b' : '#64748b',
//     fontWeight: isActive ? '500' : '400',
//     borderLeft: isActive ? '2px solid #3b82f6' : '2px solid transparent',
//     textDecoration: 'none',
//     transition: 'all 0.15s',
//   });

//   return (
//     <div style={{ display: 'flex', minHeight: '100vh' }}>
//       {/* Sidebar */}
//       <div style={{
//         width: open ? '260px' : '0px',
//         minWidth: open ? '260px' : '0px',
//         overflow: 'hidden',
//         transition: 'width 0.25s ease, min-width 0.25s ease',
//         backgroundColor: '#f8fafc',
//         borderRight: '1px solid #e2e8f0',
//         display: 'flex',
//         flexDirection: 'column',
//       }}>
//         <div style={{ padding: '16px', borderBottom: '1px solid #e2e8f0', fontSize: '12px', fontWeight: '600', color: '#94a3b8', letterSpacing: '0.05em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>
//           2iE — Navigation
//         </div>

//         <nav style={{ flex: 1, overflowY: 'auto' }}>
//           {/* Ressources */}
//           <button onClick={() => toggleSection('ressources')} style={{ width: '100%', background: 'none', border: 'none', padding: '10px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', fontSize: '14px', fontWeight: '500', whiteSpace: 'nowrap' }}>
//             Ressources <span>{openSections.ressources ? '▾' : '▸'}</span>
//           </button>
//           {openSections.ressources && RESSOURCES.map(l => (
//             <NavLink key={l.path} to={l.path} style={({ isActive }) => subItemStyle(isActive)}>{l.label}</NavLink>
//           ))}

//           {/* Gestion étudiants */}
//           <button onClick={() => toggleSection('etudiants')} style={{ width: '100%', background: 'none', border: 'none', padding: '10px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', fontSize: '14px', fontWeight: '500', whiteSpace: 'nowrap' }}>
//             Gestion des étudiants <span>{openSections.etudiants ? '▾' : '▸'}</span>
//           </button>
//           {openSections.etudiants && ETUDIANTS.map(l => (
//             <NavLink key={l.path} to={l.path} style={({ isActive }) => subItemStyle(isActive)}>{l.label}</NavLink>
//           ))}
//         </nav>
//       </div>

//       {/* Main content */}
//       <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
//         <div style={{ height: '52px', borderBottom: '1px solid #e2e8f0', display: 'flex', alignItems: 'center', padding: '0 16px', gap: '12px' }}>
//           <button onClick={() => setOpen(o => !o)} style={{ background: 'none', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '6px 10px', cursor: 'pointer', fontSize: '16px' }}>
//             ☰
//           </button>
//           <span style={{ fontWeight: '500' }}>Menu</span>
//         </div>
//         <div style={{ flex: 1, padding: '32px' }}>
//           {children}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Sidebar;